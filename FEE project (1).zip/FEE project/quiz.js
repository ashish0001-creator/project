const questions = [
    {
        question: "When was the first programming language created?",
        choices: ["1876", "1884", "1879", "1883"],
        correctAnswer: "1883",
    },
    {
        question: "Which programming language is used for web development?",
        choices: ["Java", "Python", "JavaScript", "C++"],
        correctAnswer: "JavaScript",
    },
    {
        question: "Who is known as the father of computer?",
        choices: ["Henrey Ford", "Charles Babbage", "Wilbur", "Michal Charles"],
        correctAnswer: "Charles Babbage"
    },
        {
            question: "Who made significant contribution to AI?",
            choices: ["Alan Turing", "Newton", "Wilbur", "Backus John"],
            correctAnswer: "Alan Turing"
        },
        {
            question: "Who invented the World Wide Web (WWW)?",
            choices: ["Barbara Liskov", "James Gosling", "Ray Tomlinson", "Timothy John Berners-Lee"],
            correctAnswer: "Timothy John Berners-Lee"
        },

];
let currentQuestionIndex = 0;
let score = 0;

const questionElement = document.getElementById("question");
const choicesElement = document.getElementById("choices");
const scoreElement = document.getElementById("score");
const nextButton = document.getElementById("next-button");

function displayQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    questionElement.textContent = currentQuestion.question;

    choicesElement.innerHTML = "";
    currentQuestion.choices.forEach((choice) => {
        const choiceButton = document.createElement("button");
        choiceButton.textContent = choice;
        choiceButton.addEventListener("click", () => checkAnswer(choice));
        choicesElement.appendChild(choiceButton);
    });

    scoreElement.textContent = `Score: ${score}`;
}

function checkAnswer(selectedChoice) {
    const currentQuestion = questions[currentQuestionIndex];
    if (selectedChoice === currentQuestion.correctAnswer) {
        score++;
    }
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        displayQuestion();
    } else {
        endQuiz();
    }
}

function endQuiz() {
    questionElement.textContent = "Quiz Over!";
    choicesElement.innerHTML = "";
    nextButton.style.display = "none";
    scoreElement.textContent = `Final Score: ${score}`;
}

nextButton.addEventListener("click", () => {
    if (currentQuestionIndex < questions.length) {
        displayQuestion();
    } else {
        endQuiz();
    }
});


displayQuestion();

